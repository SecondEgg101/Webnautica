Thanks for playing with Webnautica!
Adds creatures from Subnautica as catchable fish.
Version: 1.0.1
Authors: SecondEgg


This mod was made with Hatchery 1.2.0
https://github.com/coolbot100s/Hatchery